package application;

import java.io.InputStream;
import java.net.URL;
import java.util.ResourceBundle;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

public class SampleController implements Initializable {
	@FXML
	private Button actualitza_button;
	@FXML
	private Label label_total_monedes;
	@FXML
	private Label label_peixos_total;
	@FXML
	private Label total_usuaris_registrat;
	@FXML
	private Label monedes_pendents;
	@FXML
	private ImageView image_field;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		recuperarDades();
		
	}
	
	public void recuperarDades() {
		try {
			URL url = new URL("https://fi-curs-cloned-srovira.c9users.io/getEstadistiques/");
			try (InputStream is = url.openStream(); JsonReader rdr = Json.createReader(is)) {
				JsonObject jsonObject = rdr.readObject();
				JsonObject innerJsonObject = jsonObject.getJsonObject("dades");
				label_total_monedes.setText(Integer.toString(innerJsonObject.getInt("total_monedes")));
				label_peixos_total.setText(Integer.toString(innerJsonObject.getInt("total_peixos")));
				total_usuaris_registrat.setText(Integer.toString(innerJsonObject.getInt("total_usuaris")));
				monedes_pendents.setText(Integer.toString(innerJsonObject.getInt("total_monedes_pendents")));
				is.close();
				rdr.close();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
